package com.example.Report.AI.project.controllers;

import com.example.Report.AI.project.daos.dtos.HouseholdDTO;
import com.example.Report.AI.project.daos.dtos.PetInfoDTO;
import com.example.Report.AI.project.entities.Household;
import com.example.Report.AI.project.entities.Pet;
import com.example.Report.AI.project.services.HouseService;
import com.example.Report.AI.project.services.PetService;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class GraphQLResolver {

    private final HouseService houseService;
    private final PetService petService;

    public GraphQLResolver(HouseService houseService, PetService petService) {
        this.houseService = houseService;
        this.petService = petService;
    }

    // Queries
    public List<Household> getAllHouseholds() {
        return houseService.getAllHouseholds();
    }

    public Household getHousehold(Long id) {
        return houseService.getHouseholdByIdIncludingPets(id).orElse(null);
    }

    public List<Pet> getAllPets() {
        return petService.getAllPets();
    }

    public Pet getPet(Long id) {
        return petService.getPetById(id).orElse(null);
    }

    // Mutations
    public Household createHousehold(String eircode, int no_occupants, int max_occupants, int owner_occupied) {
        Household household = new Household();
        household.setEircode(eircode);
        household.setNo_occupants(no_occupants);
        household.setMax_occupants(max_occupants);
        household.setOwner_occupied(owner_occupied);
        return houseService.addNewHousehold(household);
    }

    public Pet createPet(String name, Long householdId) {
        Household household = houseService.getHouseholdByIdIncludingPets(householdId).orElse(null);
        Pet pet = new Pet();
        pet.setName(name);
        pet.setHousehold(household);
        return petService.addPet(pet);
    }


    public Long deletePet(Long id) {
        petService.deletePetById(id);
        return id;
    }

    public Long deleteHousehold(Long id) {
        houseService.deleteHouseholdById(id);
        return id;
    }
}