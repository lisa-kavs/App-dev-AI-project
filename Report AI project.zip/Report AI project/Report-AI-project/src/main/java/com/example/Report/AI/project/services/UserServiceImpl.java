package com.example.Report.AI.project.services;

import com.example.Report.AI.project.daos.UserRepository;
import com.example.Report.AI.project.entities.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserServiceImpl {
    @Autowired
    private UserRepository userRepository;

    public User createUser(User user) {
        // Encrypt password before saving
        user.setPassword(encryptPassword(user.getPassword()));
        return userRepository.save(user);
    }

    public Optional<User> resetPassword(Long id, String newPassword) {
        Optional<User> userOptional = userRepository.findById(id);
        if (userOptional.isPresent()) {
            User user = userOptional.get();
            user.setPassword(encryptPassword(newPassword));
            return Optional.of(userRepository.save(user));
        }
        return Optional.empty();
    }

    public Optional<User> toggleUnlockedStatus(Long id) {
        Optional<User> userOptional = userRepository.findById(id);
        if (userOptional.isPresent()) {
            User user = userOptional.get();
            user.setUnlocked(!user.isUnlocked());
            return Optional.of(userRepository.save(user));
        }
        return Optional.empty();
    }

    public void deleteUser(Long id) {
        if (userRepository.existsById(id)) {
            userRepository.deleteById(id);
        }
    }
}
