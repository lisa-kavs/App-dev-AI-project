package com.example.Report.AI.project.daos.dtos;

public record PetStatisticsDTO(double averageAge, long totalCount) {
}
