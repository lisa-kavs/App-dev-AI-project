package com.example.Report.AI.project.services;


import com.example.Report.AI.project.daos.PetRepository;
import com.example.Report.AI.project.daos.dtos.PetInfoDTO;
import com.example.Report.AI.project.daos.dtos.PetStatisticsDTO;
import com.example.Report.AI.project.entities.Pet;
import com.example.Report.AI.project.services.exceptions.NotFoundException;
import com.example.Report.AI.project.services.exceptions.PetNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PetServiceImpl implements PetService{
    @Autowired
    private PetRepository petRepository;

    @Override
    public Pet addPet(Pet pet) {
        return petRepository.save(pet);
    }

    @Override
    public List<Pet> getAllPets() {
        return petRepository.findAll();
    }

    @Override
    public Optional<Pet> getPetById(Long id) {
        return petRepository.findById(id);
    }

    @Override
    public Pet updatePet(Long id, Pet petDetails) throws PetNotFoundException {
        return petRepository.findById(id).map(existingPet -> {
            existingPet.setName(petDetails.getName());
            existingPet.setType(petDetails.getType());
            existingPet.setAge(petDetails.getAge());
            return petRepository.save(existingPet);
        }).orElseThrow(() -> new PetNotFoundException(id));
    }

    @Override
    public void deletePetById(Long id) throws PetNotFoundException {
        Pet pet = petRepository.findById(id).orElseThrow(() -> new PetNotFoundException(id));
        petRepository.delete(pet);
    }

    @Override
    public void deletePetByName(String name) throws PetNotFoundException {
//        Pet pet = petRepository.findByNameIgnoreCase(name).orElseThrow(() -> new PetNotFoundException("Pet with name " + name + " not found"));
        Pet pet = petRepository.findByNameIgnoreCase(name).orElseThrow(()-> new NotFoundException(name));
        petRepository.delete(pet);
    }

    @Override
    public List<Pet> getPetsByType(String type) {
        return petRepository.findByTypeIgnoreCase(type);
    }

    @Override
    public List<Pet> getPetsByBreedOrderedByAge(String breed) {
        return petRepository.findByBreedIgnoreCaseOrderByAge(breed);
    }

    @Override
    public List<PetInfoDTO> getPetInfoList() {
        return petRepository.findPetInfo();
    }

    @Override
    public PetStatisticsDTO getPetStatistics() {
        return petRepository.findPetStatistics();
    }



}
