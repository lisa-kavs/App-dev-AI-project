package com.example.Report.AI.project.controllers;

import com.example.Report.AI.project.daos.dtos.PetInfoDTO;
import com.example.Report.AI.project.entities.Pet;
import com.example.Report.AI.project.services.HouseService;
import com.example.Report.AI.project.services.PetService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

//import javax.validation.Valid; (suggests using this import)
import jakarta.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/api/pets")
public class PetController {

    private final PetService petService;
    private final HouseService houseService;

    public PetController(PetService petService, HouseService houseService) {
        this.petService = petService;
        this.houseService = houseService;
    }

    @GetMapping
    public List<Pet> getAllPets() {
        return petService.getAllPets();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Pet> getPet(@PathVariable Long id) {
        return petService.getPetById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<Pet> createNewPet(@Valid @RequestBody PetInfoDTO dto) {
        Pet pet = new Pet();
        pet.setName(dto.name());
        pet.setHousehold(houseService.getHouseholdByIdIncludingPets(dto.HouseholdID()).orElseThrow());

        return new ResponseEntity<>(petService.addPet(pet), HttpStatus.CREATED);
    }

    @PatchMapping("/{id}/name")
    public ResponseEntity<Pet> changePetName(@PathVariable Long id, @Valid @RequestBody PetInfoDTO dto) {
        return petService.updatePet(id, dto.name())
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePet(@PathVariable Long id) {
        petService.deletePetById(id);
        return ResponseEntity.noContent().build();
    }
}