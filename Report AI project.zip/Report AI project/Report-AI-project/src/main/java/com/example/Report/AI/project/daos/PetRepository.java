package com.example.Report.AI.project.daos;

import com.example.Report.AI.project.daos.dtos.PetInfoDTO;
import com.example.Report.AI.project.daos.dtos.PetStatisticsDTO;
import com.example.Report.AI.project.entities.Pet;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface PetRepository extends JpaRepository<Pet, Long> {
    @Query("SELECT p FROM Pet p WHERE LOWER(p.name) = LOWER(:name)") // Case-insensitive query
    Optional<Pet> findByNameIgnoreCase(@Param("name") String name);

    List<Pet> findByTypeIgnoreCase(String type);

    List<Pet> findByBreedIgnoreCaseOrderByAge(String breed);

    @Query("SELECT new com.example.Report.AI.project.dtos.PetInfoDTO(p.name, p.type, p.breed) FROM Pet p")
    List<PetInfoDTO> findPetInfo();

    @Query("SELECT new com.example.Report.AI.project.dtos.PetStatisticsDTO(AVG(p.age), COUNT(p)) FROM Pet p")
    PetStatisticsDTO findPetStatistics();

    List<Pet> findByHouseholdId(Long householdId);

    List<Pet> findByNameIgnoreCase2(String name);




}
