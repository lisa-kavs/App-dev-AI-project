package com.example.Report.AI.project.controllers;

import com.example.Report.AI.project.daos.dtos.HouseholdDTO;
import com.example.Report.AI.project.entities.Household;
import com.example.Report.AI.project.services.HouseService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/api/households")
public class HouseController {

    private final HouseService houseService;

    public HouseController(HouseService houseService) {
        this.houseService = houseService;
    }

    @GetMapping
    public List<Household> getAllHouseholds() {
        return houseService.getAllHouseholds();
    }

    @GetMapping("/no-pets")
    public List<Household> getHouseholdsWithNoPets() {
        return houseService.getHouseholdsWithNoPets();
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<Household> getHousehold(@PathVariable Long id) {
        return houseService.getHouseholdByIdIncludingPets(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

//    Insists on using methods that don't exist in the project
//    @PostMapping
//    public ResponseEntity<Household> createNewHousehold(@Valid @RequestBody HouseholdDTO dto) {
//        Household household = new Household();
//        household.setAddress(dto.address());
//        household.setResidentName(dto.residentName());
//        household.setCurrentOccupants(dto.currentOccupants());
//        household.setMaxOccupancy(dto.maxOccupancy());
//        household.setOwnerOccupied(dto.ownerOccupied());
//
//        return new ResponseEntity<>(houseService.addNewHousehold(household), HttpStatus.CREATED);
//    }

        @PostMapping
    public ResponseEntity<Household> createNewHousehold(@Valid @RequestBody HouseholdDTO dto) {
        Household household = new Household();
        household.setEircode(dto.eircode());
        household.setMax_occupants(dto.max_occupants());
        household.setOwner_occupied(dto.owner_occupied());
        household.setNo_occupants(dto.no_occupants());


        return new ResponseEntity<>(houseService.addNewHousehold(household), HttpStatus.CREATED);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteHousehold(@PathVariable Long id) {
        houseService.deleteHouseholdById(id);
        return ResponseEntity.noContent().build();
    }
}