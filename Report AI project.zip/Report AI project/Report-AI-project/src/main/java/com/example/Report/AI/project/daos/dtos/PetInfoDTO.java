package com.example.Report.AI.project.daos.dtos;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record PetInfoDTO(
       @NotBlank String name,
        String type,
        String breed,
        @NotNull Long HouseholdID
) {
}
