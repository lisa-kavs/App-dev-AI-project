package com.example.Report.AI.project.services;

import com.example.Report.AI.project.entities.User;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public interface UserService {
   public User createUser(User user);
   public Optional<User> resetPassword(Long id, String newPassword);
   public Optional<User> toggleUnlockedStatus(Long id);
   public void deleteUser(Long id);
}
