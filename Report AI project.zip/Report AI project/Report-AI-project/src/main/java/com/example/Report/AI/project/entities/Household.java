package com.example.Report.AI.project.entities;

import jakarta.persistence.*;
import lombok.*;

import java.util.List;

//@Entity
//@Getter
//@Setter
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Household {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String eircode;
    private int no_occupants;
    private int max_occupants;
    private int owner_occupied;


    @OneToMany(mappedBy = "household",orphanRemoval = true, cascade= CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Pet> pets;

//    Insists on using getters and setters this way instead of using lombok takes asking a lot to make it finally suggest using lombok
//    public void setPets(List<Pet> pets) {
//        this.pets = pets;
//    }

//    public int getOwnerOccupied() {
//        return ownerOccupied;
//    }
//
//    public void setOwnerOccupied(int ownerOccupied) {
//        this.ownerOccupied = ownerOccupied;
//    }




}
