package com.example.Report.AI.project;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class Aspects {

    @Before("execution(* com.example.Report.AI.project.services.HouseService.*(..))")
    public void logBeforeMethodExecution() {
        System.out.println("Executing method in HouseholdService...");
    }

}
