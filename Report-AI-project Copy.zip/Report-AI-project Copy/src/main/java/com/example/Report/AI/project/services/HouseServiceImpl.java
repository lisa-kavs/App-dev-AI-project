package com.example.Report.AI.project.services;

import com.example.Report.AI.project.daos.HouseRepository;
import com.example.Report.AI.project.daos.PetRepository;
import com.example.Report.AI.project.entities.Household;
import com.example.Report.AI.project.entities.Pet;
import com.example.Report.AI.project.services.exceptions.HouseholdNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
public class HouseServiceImpl implements HouseService{

    @Autowired
    private HouseRepository householdRepository;

    @Autowired
    private PetRepository petRepository;


    public Optional<Household> findHouseholdByEircodeWithoutPets(String eircode) {
        return householdRepository.findHouseholdByEircodeWithoutPets(eircode);
    }

    public Optional<Household> findHouseholdByEircodeWithPets(String eircode) {
        return householdRepository.findHouseholdByEircodeWithPets(eircode);
    }

    public List<Household> findHouseholdsWithNoPets() {
        return householdRepository.findHouseholdsWithNoPets();
    }

    @Override
    public Household addNewHousehold(Household household) {
        return householdRepository.save(household);
    }

    @Override
    public List<Household> getAllHouseholds() {
        return householdRepository.findAll();
    }

    @Override
    public Optional<Household> getHouseholdByIdExcludingPets(Long id) {
        return householdRepository.findById(id)
                .map(household -> {
                    household.setPets(null); // Assuming `Household` has a `pets` field
                    return household;
                });
    }

    @Override
    public Optional<Household> getHouseholdByIdIncludingPets(Long id) {
        return householdRepository.findById(id);
    }

    @Override
    public Household updateHousehold(Long id, Household householdDetails) {
        return householdRepository.findById(id).map(household -> {
            household.setEircode(householdDetails.getEircode()); // Update desired fields
            household.setNo_occupants(householdDetails.getNo_occupants());
            household.setOwner_occupied(householdDetails.getOwner_occupied());
            householdDetails.setMax_occupants(householdDetails.getMax_occupants());
            // Add more fields as necessary
            return householdRepository.save(household);
        }).orElseThrow(() -> new HouseholdNotFoundException("Household not found with id: " + id));
    }

    @Override
    public void deleteHouseholdById(Long id) {
        Household existingHousehold = householdRepository.findById(id)
                .orElseThrow(() -> new HouseholdNotFoundException("Household not found with id: " + id));

        householdRepository.delete(existingHousehold);
    }

    @Override
    public void deletePetsByName(String petName) {
        List<Pet> petsToDelete = petRepository.findByNameIgnoreCase2(petName);
        petRepository.deleteAll(petsToDelete);
    }

    @Override
    public List<Household> getHouseholdsWithNoPets() {
        return householdRepository.findByPetsIsNullOrPetsEmpty();
    }

    @Override
    public List<Household> getOwnerOccupiedHouseholds() {
        return householdRepository.findByOwnerOccupied(1); // Retrieve only owner-occupied households
    }

    @Override
    public Map<String, Long> getHouseholdStatistics() {
        long householdsWithoutOccupants = householdRepository.countByCurrentOccupants(0);
        long householdsWithMaxOccupancy = householdRepository.countByCurrentOccupantsEqualsMaxOccupancy();

        Map<String, Long> statistics = new HashMap<>();
        statistics.put("householdsWithoutOccupants", householdsWithoutOccupants);
        statistics.put("householdsWithMaxOccupancy", householdsWithMaxOccupancy);

        return statistics;
    }




}
