package com.example.Report.AI.project.services;


import com.example.Report.AI.project.entities.Household;

import java.util.List;
import java.util.Map;
import java.util.Optional;

public interface HouseService {
    Optional<Household> findHouseholdByEircodeWithoutPets(String eircode);
    Optional<Household> findHouseholdByEircodeWithPets(String eircode);
    List<Household> findHouseholdsWithNoPets();
    Household addNewHousehold(Household household);
    List<Household> getAllHouseholds();
    Optional<Household> getHouseholdByIdExcludingPets(Long id);
    Optional<Household> getHouseholdByIdIncludingPets(Long id);
    Household updateHousehold(Long id, Household householdDetails);
    void deleteHouseholdById(Long id);
    void deletePetsByName(String petName);
    List<Household> getHouseholdsWithNoPets();
    List<Household> getOwnerOccupiedHouseholds();
    Map<String, Long> getHouseholdStatistics();

}
