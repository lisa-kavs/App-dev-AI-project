package com.example.Report.AI.project.daos;

import com.example.Report.AI.project.entities.Household;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface HouseRepository extends JpaRepository<Household, Long> {
    @Query("SELECT h FROM Household h LEFT JOIN h.pets p WHERE h.eircode = :eircode AND p IS NULL")
    Optional<Household> findHouseholdByEircodeWithoutPets(String eircode);

    @Query("SELECT h FROM Household h JOIN FETCH h.pets WHERE h.eircode = :eircode")
    Optional<Household> findHouseholdByEircodeWithPets(@Param("eircode") String eircode);

    @Query("SELECT h FROM Household h LEFT JOIN h.pets p WHERE p IS NULL")
    List<Household> findHouseholdsWithNoPets();

    List<Household> findByPetsIsNullOrPetsEmpty();
    List<Household> findByOwnerOccupied(int ownerOccupied);

    long countByCurrentOccupants(int occupants);

    @Query("SELECT COUNT(h) FROM Household h WHERE h.no_occupants = h.max_occupants")
    long countByCurrentOccupantsEqualsMaxOccupancy();


}
