package com.example.Report.AI.project.daos.dtos;

public record HouseholdDTO(String eircode, int no_occupants, int max_occupants, int owner_occupied) {
}
