package com.example.Report.AI.project.services.exceptions;

public class PetNotFoundException extends RuntimeException {
    public PetNotFoundException(Long id) {
        super("Pet with ID " + id + " not found");
    }
}
