package com.example.Report.AI.project.services;

import com.example.Report.AI.project.daos.dtos.PetInfoDTO;
import com.example.Report.AI.project.daos.dtos.PetStatisticsDTO;
import com.example.Report.AI.project.entities.Pet;
import com.example.Report.AI.project.services.exceptions.PetNotFoundException;

import java.util.List;
import java.util.Optional;

public interface PetService {
    Pet addPet(Pet pet);
    List<Pet> getAllPets();
    Optional<Pet> getPetById(Long id);
    Pet updatePet(Long id, Pet petDetails);
    void deletePetById(Long id) throws PetNotFoundException;
    void deletePetByName(String name) throws PetNotFoundException;
    List<Pet> getPetsByType(String type);
    List<Pet> getPetsByBreedOrderedByAge(String breed);
    List<PetInfoDTO> getPetInfoList();
    PetStatisticsDTO getPetStatistics();
}
